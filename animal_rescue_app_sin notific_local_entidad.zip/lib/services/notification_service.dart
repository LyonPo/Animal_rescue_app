import 'package:firebase_messaging/firebase_messaging.dart';

class NotificationService {

  final FirebaseMessaging _firebaseMessaging =
      FirebaseMessaging.instance;

  Future<void> initialize() async {

    // PERMISOS
    await _firebaseMessaging
        .requestPermission();

    // TOKEN DEVICE
    String? token =
        await _firebaseMessaging.getToken();

    print('FCM TOKEN: $token');

    // FOREGROUND
    FirebaseMessaging.onMessage.listen(

      (RemoteMessage message) {

        print(
          'Nueva notificación: '
          '${message.notification?.title}',
        );
      },
    );
  }
}